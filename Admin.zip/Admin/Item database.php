<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "registration");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$code = mysqli_real_escape_string($link, $_REQUEST['code']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$category = mysqli_real_escape_string($link, $_REQUEST['category']);
$sub = mysqli_real_escape_string($link, $_REQUEST['sub']);
$quantity = mysqli_real_escape_string($link, $_REQUEST['quantity']);
$price = mysqli_real_escape_string($link, $_REQUEST['price']);
 
// attempt insert query execution
$sql = "INSERT INTO item (code,name, category, sub,quantity,price) VALUES ('$code','$name', '$category', '$sub','$quantity','$price')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully."; header('location: Manage Item.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 

 
// close connection
mysqli_close($link);
?>