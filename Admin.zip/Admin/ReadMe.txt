---------------------------------------------------------------------------

KAVINDU SACHINTHA LIYANAGE
Phone: 0710768126
Email: kavindusachintha1625@gmail.com
LinkedIn: https://www.linkedin.com/in/kavindu-sachintha-31474523a

---------------------------How-to setup Project----------------------------


1. Download the zip file

2. Extract the file or copy "Admin" folder

3. Paste inside root directory/ where you install xammp local disk and paste for xampp/htdocs 
 
4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name registration

6. Import registration.sql file(given inside the zip package in Database File)

7. Run the script http://localhost/Admin/

------------****LOGIN DETAILS****--------------

USERNAME : admin

PASSWORD : Test@123456


