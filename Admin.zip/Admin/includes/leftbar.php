	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				
				<br>
			


<li><a href="#"><i class="fa fa-sitemap"></i> Customers Management</a>
					<ul>
						<li><a href="Register Customer.php">Customer Registration</a></li>
						<li><a href="Manage Customer.php">Manage Customer</a></li>
						<li><a href="Customer Report.php">Customer Report</a></li>

					</ul>
				</li>
				<li><a href="#"><i class="fa fa-users"></i> Item Management </a>
				<ul>
				<li><a href="Add Item.php">Add Item</a></li>
				<li><a href="Manage Item.php">Manage Item</a></li>
				<li><a href="Item Report.php">Item Report</a></li>
				</ul>
		</nav>