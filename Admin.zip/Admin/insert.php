<?php
$link = mysqli_connect("localhost", "root", "", "registration");
 

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 

$utitle = mysqli_real_escape_string($link, $_REQUEST['utitle']);
$first_name = mysqli_real_escape_string($link, $_REQUEST['first_name']);
$last_name = mysqli_real_escape_string($link, $_REQUEST['last_name']);
$contact_number = mysqli_real_escape_string($link, $_REQUEST['contact_number']);
$district = mysqli_real_escape_string($link, $_REQUEST['district']);
 

$sql = "INSERT INTO customer (utitle,first_name, last_name, contact_number,district) VALUES ('$utitle','$first_name', '$last_name', '$contact_number','$district')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully."; header('location: Manage Customer.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 

 
// close connection
mysqli_close($link);
?>